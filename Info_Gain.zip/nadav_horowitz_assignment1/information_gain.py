import math
import pandas as pd


def getData():
    #dataSetName = input("Please enter the dataset file's name:")
    #dataSetName = "assets/" + dataSetName + ".csv"
    dataSetName = "assets/playtennis.csv"
    originalDataSet = pd.read_csv(dataSetName)
    return originalDataSet


#column = Series object
def calculateEntropy(column):    
    numOfValues = column.size # = total number of values in column
    valueCounts = column.value_counts() # = Series object with each unique value and it's number of occurances
    entropy = 0
    for occurances in valueCounts:
        entropy = entropy + logHelper(occurances,numOfValues)
    entropy = entropy * -1
    return entropy
    
    
def logHelper(occurances, numOfValues):
    return occurances/numOfValues * math.log2(occurances/numOfValues)    
    
    
#reducedData is a dataFrame containing the feature column and the target column
def calculate2ndTerm(reducedData, featureColumnName):
    reducedData = reducedData.sort_values(by=featureColumnName) #sort reducedData by feature values to make it easy to iterate
    
    sum = 0 #tracks weighted entropies of partition
    
    countElements = 0.0 #counter needed for iteration
    dataSetSize = reducedData.size / 2 #used to calculate weighting and needed for iteration
    
    prevFeatureValue = "" #used to check for new outcome in sorted reducedData table    
    classValues = [] #used to store target column values for an outcome
    
    tuples = reducedData.itertuples() #get dataFrame as a list of tuples, one tuple for each row
    
    #iterate ruducedData
    for tuple in tuples:
        countElements = countElements + 1
        featureValue = tuple[1]
        
        #if outcome is same as the previous and not the last row in the dataframe, or if it's the first row in the dataframe
        if(countElements != dataSetSize and featureValue == prevFeatureValue or len(classValues) == 0):
            classValue = tuple[2]
            classValues.append(classValue)#get the classValue and add it to the classValues list
            prevFeatureValue = featureValue
            
        #otherwise we've reached a new outcome, or we've reached the last row in the dataframe
        else:
            
            #if outcome is same as previous, and we've reached the last row in the dataframe
            if(featureValue == prevFeatureValue and countElements == dataSetSize):
                classValue = tuple[2]
                classValues.append(classValue)#get the classValue and add it to the classValues list
             
            classValuesDF = pd.DataFrame(classValues)#construct dataframe from classValues list
                        
            outcomeSize = classValuesDF.size#get number of datapoints of outcome
            weighting = outcomeSize / dataSetSize#calculate weighting factor
            
            outcomeEntropy = calculateEntropy(classValuesDF)#calculate entropy of outcome
            weightedEntropy = weighting * outcomeEntropy#apply weighting factor
            sum = sum + weightedEntropy#add new weighted entropy of partition to tracker
            
            classValues = []#reset classValues list for new outcome
            classValue = tuple[2]
            classValues.append(classValue)#get the classValue and add it to the classValues list
            
            prevFeatureValue = featureValue#increment featureValue tracker            
    return sum
    

def main():
    data = getData() #data is a dataframe containing the dataset
    columnSet = data.keys().values #columnSet is an array containing the names of the columns
    
    targetColumnName = columnSet[-1]
    targetColumn = data[targetColumnName]
    targetEntropy = calculateEntropy(targetColumn)
    
    lastFeatureIndex = len(columnSet) - 1 #get index of last feature column
    
    #Loop through each column in the data set, calculating the IG for each
    for featureColumnNumber in range(1,lastFeatureIndex):
        featureColumnName = columnSet[featureColumnNumber]
    
        featureColumnFrame = data[featureColumnName].to_frame()
        targetColumnFrame = targetColumn.copy(deep=True).to_frame()
        reducedData = featureColumnFrame.join(targetColumnFrame) #reducedData is a dataframe with 1 feature column & 1 class column
        
        secondTerm = calculate2ndTerm(reducedData,featureColumnName)
        
        infoGain = round(targetEntropy - secondTerm,3)
        
        print("Information Gain Of Feature " + featureColumnName + " = " + str(infoGain))
        
main()